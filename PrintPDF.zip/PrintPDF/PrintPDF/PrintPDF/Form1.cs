﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrintPDF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //WindowSpooler.SendFileToPrinter("Microsoft Print to PDF",@"A:\output\test.pdf");
            string s = "Hello"; // device-dependent string, need a FormFeed?

            // Allow the user to select a printer.
            PrintDialog pd = new PrintDialog();
            pd.PrinterSettings = new PrinterSettings();
            if (DialogResult.OK == pd.ShowDialog(this))
            {
                // Send a printer-specific to the printer.
                WindowSpooler.SendStringToPrinter(pd.PrinterSettings.PrinterName, s);
            }
         

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Allow the user to select a file.
            //OpenFileDialog ofd = new OpenFileDialog();
           // if (DialogResult.OK == ofd.ShowDialog(this))
            //{
                // Allow the user to select a printer.
                PrintDialog pd = new PrintDialog();
                pd.PrinterSettings = new PrinterSettings();
                //pd.PrinterSettings.PrintToFile = true;
                //pd.PrinterSettings.PrintFileName = @"A:\output\sample.pdf";
                
                //if (DialogResult.OK == pd.ShowDialog(this))
                //{
                    // Print the file to the printer.
                    WindowSpooler.SendFileToPrinter(pd.PrinterSettings.PrinterName, @"A:\output\sampleDocument.docx");
                //}
            //}
        }
    }
}
