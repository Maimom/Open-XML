﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintPDF
{
    public class ProcessThread
    {
        public void PrintPDF()
        {
            Process printjob = new Process();

            printjob.StartInfo.FileName = @"A:/output/SampleDocument.docx";
            printjob.StartInfo.Verb = "Print";
            // printjob.UseShellExecute = true;
            printjob.StartInfo.CreateNoWindow = true;
            printjob.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            PrinterSettings setting = new PrinterSettings();
            setting.DefaultPageSettings.Landscape = true;
            setting.PrintToFile = true;
            setting.PrintFileName = @"A:/output/SampleDocument.pdf";


            printjob.Start();
        }
       
    }
}
