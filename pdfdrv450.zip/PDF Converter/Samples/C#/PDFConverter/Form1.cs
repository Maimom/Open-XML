/*
 
This sample project illustrates how use the Amyuni PDF Converter with C#
 
You can download a fully functional evaluation version of the product from the link below:
 
 http://www.amyuni.com/en/developer/pdfconverter
 
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Printing; 
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Drawing.Imaging;
using CDIntfEx;
using Microsoft.Win32;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Text;


namespace PDFConverter
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnPrintExcel;
        private System.Windows.Forms.Button btnPrintWord;
        private System.Windows.Forms.TextBox txtActivationCode;
        private System.Windows.Forms.TextBox txtLicenseTo;
        private System.Windows.Forms.TextBox txtPrinterName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPrintText;
        private System.Drawing.Printing.PrintDocument printDocument1;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;


        ////////////////////////////////////////////////////////
        //create PDF printer constants	
        const string PDFprinter = "Amyuni PDF Converter";
        const Int32 sNoPrompt = 0x01;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnExportToRtf;
        const int s = 0x12;
        const Int32 sUseFileName = 0x02;
        const Int32 sBroadCast = 0x20;
        const Int32 iConcat = 0x04;
        const Int32 sEmbedFonts = 0x10;
        const Int32 lExportToRtf = 0x8000000;
        const Int32 lExportToTIFF = 0x8000000;
        const Int32 JPEGExport = 0x10000000;
        const Int32 FullEmbed = 0x200;
        const Int32 MultilingualSupport = 0x80;
        const Int32 JPegLevelMedium = 0x00040000;
        const Int32 PrintWatermark = 0x40;
        const Int32 SendToCreator = 0x2000000;
        const Int32 EmbedStandardFonts = 0x00200000;
        const Int32 ConvertHyperlinks = 0x00100000;
        const Int32 AddIdNumber       =  0x00004000;
        const Int32 AddDateTime = 0x00003000;

        //Evaluation Codes of the Amyuni PDF Suite
        const string strLicenseTo = "Amyuni Technologies Eval Version";
        const string strActivationCode = "07EFCDAB0100010031825101B257659266255C64F543DF28853EEACF7AFD9DC81D66B62926B87CEC1161728458C731CE6C2429A6B440";
        


        private System.Windows.Forms.Button btnExportTiff;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnAppend;
        private System.Windows.Forms.Button btnEncrypt;
        private System.Windows.Forms.Button btnExportToHtml;
        private System.Windows.Forms.Button btnPrintRTF;
        private System.Windows.Forms.Button btnExportToJPEG;
        private System.Windows.Forms.Button btnChangeProperties;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Button btnBatchConvert;
        private System.Windows.Forms.Button btnPrintTFF;
        private System.Windows.Forms.Button btnPrintExportToExcel;
        private System.Windows.Forms.Button btnPrintPowerPoint;
        private Button btnThread;
        private Label lblPagePrint;
        private System.Windows.Forms.Button btnPrintPDFDoc;



        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
            txtLicenseTo.Text = strLicenseTo;
            txtActivationCode.Text = strActivationCode;
            txtPrinterName.Text = PDFprinter;

            printDocument1.PrintController = new StandardPrintController();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnThread = new System.Windows.Forms.Button();
            this.btnBatchConvert = new System.Windows.Forms.Button();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.btnPrintPDFDoc = new System.Windows.Forms.Button();
            this.btnPrintText = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnPrintPowerPoint = new System.Windows.Forms.Button();
            this.btnPrintExcel = new System.Windows.Forms.Button();
            this.btnPrintWord = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnPrintExportToExcel = new System.Windows.Forms.Button();
            this.btnPrintTFF = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.btnExportToJPEG = new System.Windows.Forms.Button();
            this.btnPrintRTF = new System.Windows.Forms.Button();
            this.btnExportToHtml = new System.Windows.Forms.Button();
            this.btnExportTiff = new System.Windows.Forms.Button();
            this.btnExportToRtf = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnChangeProperties = new System.Windows.Forms.Button();
            this.btnAppend = new System.Windows.Forms.Button();
            this.txtActivationCode = new System.Windows.Forms.TextBox();
            this.txtLicenseTo = new System.Windows.Forms.TextBox();
            this.txtPrinterName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.lblPagePrint = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(0, 136);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(568, 240);
            this.tabControl1.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnThread);
            this.tabPage1.Controls.Add(this.btnBatchConvert);
            this.tabPage1.Controls.Add(this.btnEncrypt);
            this.tabPage1.Controls.Add(this.btnPrintPDFDoc);
            this.tabPage1.Controls.Add(this.btnPrintText);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(560, 214);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Print Text";
            // 
            // btnThread
            // 
            this.btnThread.Location = new System.Drawing.Point(196, 16);
            this.btnThread.Name = "btnThread";
            this.btnThread.Size = new System.Drawing.Size(144, 24);
            this.btnThread.TabIndex = 6;
            this.btnThread.Text = "Threading";
            this.btnThread.Click += new System.EventHandler(this.btnThread_Click);
            // 
            // btnBatchConvert
            // 
            this.btnBatchConvert.Location = new System.Drawing.Point(16, 136);
            this.btnBatchConvert.Name = "btnBatchConvert";
            this.btnBatchConvert.Size = new System.Drawing.Size(144, 24);
            this.btnBatchConvert.TabIndex = 4;
            this.btnBatchConvert.Text = "Batch Convert";
            this.btnBatchConvert.Click += new System.EventHandler(this.btnBatchConvert_Click);
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Location = new System.Drawing.Point(16, 96);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(144, 24);
            this.btnEncrypt.TabIndex = 3;
            this.btnEncrypt.Text = "Print Encrypt";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // btnPrintPDFDoc
            // 
            this.btnPrintPDFDoc.Location = new System.Drawing.Point(16, 56);
            this.btnPrintPDFDoc.Name = "btnPrintPDFDoc";
            this.btnPrintPDFDoc.Size = new System.Drawing.Size(144, 24);
            this.btnPrintPDFDoc.TabIndex = 2;
            this.btnPrintPDFDoc.Text = "Print PDF doc";
            this.btnPrintPDFDoc.Click += new System.EventHandler(this.btnPrintPDFDoc_Click);
            // 
            // btnPrintText
            // 
            this.btnPrintText.Location = new System.Drawing.Point(16, 16);
            this.btnPrintText.Name = "btnPrintText";
            this.btnPrintText.Size = new System.Drawing.Size(144, 24);
            this.btnPrintText.TabIndex = 1;
            this.btnPrintText.Text = "Print Text";
            this.btnPrintText.Click += new System.EventHandler(this.btnPrintText_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnPrintPowerPoint);
            this.tabPage2.Controls.Add(this.btnPrintExcel);
            this.tabPage2.Controls.Add(this.btnPrintWord);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(560, 214);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Print Office Products";
            this.tabPage2.Visible = false;
            // 
            // btnPrintPowerPoint
            // 
            this.btnPrintPowerPoint.Location = new System.Drawing.Point(16, 80);
            this.btnPrintPowerPoint.Name = "btnPrintPowerPoint";
            this.btnPrintPowerPoint.Size = new System.Drawing.Size(144, 24);
            this.btnPrintPowerPoint.TabIndex = 2;
            this.btnPrintPowerPoint.Text = "Print PowerPoint";
            this.btnPrintPowerPoint.Click += new System.EventHandler(this.btnPrintPowerPoint_Click);
            // 
            // btnPrintExcel
            // 
            this.btnPrintExcel.Location = new System.Drawing.Point(16, 48);
            this.btnPrintExcel.Name = "btnPrintExcel";
            this.btnPrintExcel.Size = new System.Drawing.Size(144, 24);
            this.btnPrintExcel.TabIndex = 1;
            this.btnPrintExcel.Text = "Print MsExcel";
            this.btnPrintExcel.Click += new System.EventHandler(this.btnPrintExcel_Click);
            // 
            // btnPrintWord
            // 
            this.btnPrintWord.Location = new System.Drawing.Point(16, 16);
            this.btnPrintWord.Name = "btnPrintWord";
            this.btnPrintWord.Size = new System.Drawing.Size(144, 24);
            this.btnPrintWord.TabIndex = 0;
            this.btnPrintWord.Text = "Print MsWord";
            this.btnPrintWord.Click += new System.EventHandler(this.btnPrintWord_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnPrintExportToExcel);
            this.tabPage3.Controls.Add(this.btnPrintTFF);
            this.tabPage3.Controls.Add(this.btnExportToExcel);
            this.tabPage3.Controls.Add(this.btnExportToJPEG);
            this.tabPage3.Controls.Add(this.btnPrintRTF);
            this.tabPage3.Controls.Add(this.btnExportToHtml);
            this.tabPage3.Controls.Add(this.btnExportTiff);
            this.tabPage3.Controls.Add(this.btnExportToRtf);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(560, 214);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Export Modules";
            // 
            // btnPrintExportToExcel
            // 
            this.btnPrintExportToExcel.Location = new System.Drawing.Point(384, 96);
            this.btnPrintExportToExcel.Name = "btnPrintExportToExcel";
            this.btnPrintExportToExcel.Size = new System.Drawing.Size(144, 24);
            this.btnPrintExportToExcel.TabIndex = 10;
            this.btnPrintExportToExcel.Text = "Print ExportToExcel";
            this.btnPrintExportToExcel.Click += new System.EventHandler(this.btnPrintExportToExcel_Click);
            // 
            // btnPrintTFF
            // 
            this.btnPrintTFF.Location = new System.Drawing.Point(384, 56);
            this.btnPrintTFF.Name = "btnPrintTFF";
            this.btnPrintTFF.Size = new System.Drawing.Size(144, 24);
            this.btnPrintTFF.TabIndex = 9;
            this.btnPrintTFF.Text = "PrintTIFF";
            this.btnPrintTFF.Click += new System.EventHandler(this.btnPrintTFF_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Location = new System.Drawing.Point(8, 136);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(144, 24);
            this.btnExportToExcel.TabIndex = 8;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // btnExportToJPEG
            // 
            this.btnExportToJPEG.Location = new System.Drawing.Point(8, 72);
            this.btnExportToJPEG.Name = "btnExportToJPEG";
            this.btnExportToJPEG.Size = new System.Drawing.Size(144, 24);
            this.btnExportToJPEG.TabIndex = 7;
            this.btnExportToJPEG.Text = "Export to JPEG";
            this.btnExportToJPEG.Click += new System.EventHandler(this.btnExportToJPEG_Click);
            // 
            // btnPrintRTF
            // 
            this.btnPrintRTF.Location = new System.Drawing.Point(384, 16);
            this.btnPrintRTF.Name = "btnPrintRTF";
            this.btnPrintRTF.Size = new System.Drawing.Size(144, 24);
            this.btnPrintRTF.TabIndex = 6;
            this.btnPrintRTF.Text = "Print RTF";
            this.btnPrintRTF.Click += new System.EventHandler(this.btnPrintRTF_Click);
            // 
            // btnExportToHtml
            // 
            this.btnExportToHtml.Location = new System.Drawing.Point(8, 104);
            this.btnExportToHtml.Name = "btnExportToHtml";
            this.btnExportToHtml.Size = new System.Drawing.Size(144, 24);
            this.btnExportToHtml.TabIndex = 5;
            this.btnExportToHtml.Text = "Export To Html";
            this.btnExportToHtml.Click += new System.EventHandler(this.btnExportToHtml_Click);
            // 
            // btnExportTiff
            // 
            this.btnExportTiff.Location = new System.Drawing.Point(8, 40);
            this.btnExportTiff.Name = "btnExportTiff";
            this.btnExportTiff.Size = new System.Drawing.Size(144, 24);
            this.btnExportTiff.TabIndex = 3;
            this.btnExportTiff.Text = "Export to TIFF";
            this.btnExportTiff.Click += new System.EventHandler(this.btnExportTiff_Click);
            // 
            // btnExportToRtf
            // 
            this.btnExportToRtf.Location = new System.Drawing.Point(8, 8);
            this.btnExportToRtf.Name = "btnExportToRtf";
            this.btnExportToRtf.Size = new System.Drawing.Size(144, 24);
            this.btnExportToRtf.TabIndex = 2;
            this.btnExportToRtf.Text = "Export to RTF";
            this.btnExportToRtf.Click += new System.EventHandler(this.btnExportToRtf_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnChangeProperties);
            this.tabPage4.Controls.Add(this.btnAppend);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(560, 214);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Document Object";
            // 
            // btnChangeProperties
            // 
            this.btnChangeProperties.Location = new System.Drawing.Point(16, 61);
            this.btnChangeProperties.Name = "btnChangeProperties";
            this.btnChangeProperties.Size = new System.Drawing.Size(136, 23);
            this.btnChangeProperties.TabIndex = 2;
            this.btnChangeProperties.Text = "Change Doc Properties";
            this.btnChangeProperties.Click += new System.EventHandler(this.btnChangeProperties_Click);
            // 
            // btnAppend
            // 
            this.btnAppend.Location = new System.Drawing.Point(16, 16);
            this.btnAppend.Name = "btnAppend";
            this.btnAppend.Size = new System.Drawing.Size(136, 23);
            this.btnAppend.TabIndex = 0;
            this.btnAppend.Text = "Append";
            this.btnAppend.Click += new System.EventHandler(this.btnAppend_Click);
            // 
            // txtActivationCode
            // 
            this.txtActivationCode.Location = new System.Drawing.Point(112, 58);
            this.txtActivationCode.Name = "txtActivationCode";
            this.txtActivationCode.ReadOnly = true;
            this.txtActivationCode.Size = new System.Drawing.Size(408, 20);
            this.txtActivationCode.TabIndex = 14;
            // 
            // txtLicenseTo
            // 
            this.txtLicenseTo.Location = new System.Drawing.Point(112, 34);
            this.txtLicenseTo.Name = "txtLicenseTo";
            this.txtLicenseTo.ReadOnly = true;
            this.txtLicenseTo.Size = new System.Drawing.Size(408, 20);
            this.txtLicenseTo.TabIndex = 13;
            // 
            // txtPrinterName
            // 
            this.txtPrinterName.Location = new System.Drawing.Point(112, 10);
            this.txtPrinterName.Name = "txtPrinterName";
            this.txtPrinterName.ReadOnly = true;
            this.txtPrinterName.Size = new System.Drawing.Size(408, 20);
            this.txtPrinterName.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Activation Code:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "License To:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Printer Name:";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // lblPagePrint
            // 
            this.lblPagePrint.AutoSize = true;
            this.lblPagePrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagePrint.Location = new System.Drawing.Point(15, 90);
            this.lblPagePrint.Name = "lblPagePrint";
            this.lblPagePrint.Size = new System.Drawing.Size(143, 25);
            this.lblPagePrint.TabIndex = 25;
            this.lblPagePrint.Text = "Printer Status";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(568, 390);
            this.Controls.Add(this.lblPagePrint);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.txtActivationCode);
            this.Controls.Add(this.txtLicenseTo);
            this.Controls.Add(this.txtPrinterName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Amyuni PDF Converter Sample";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new Form1());
        }

        /// <summary>
        /// This method is only used to get the working directory of this sample project.
        /// </summary>
        /// <returns>Directory path to sample project</returns>
        string getSampleWorkingDirectory()
        {
            string currentDirName = System.IO.Directory.GetCurrentDirectory();
            string[] directories = currentDirName.Split(Path.DirectorySeparatorChar);


            StringBuilder strWorkingPath = new StringBuilder();

            if (null != directories)
            {
                foreach (string direc in directories)
                {
                    strWorkingPath.Append(direc + "\\");
                    if (direc == "PDFConverter")
                    {
                        return strWorkingPath.ToString();
                    }
                }
            }
            //Can't find project
            return "";

        }
      
        /// <summary>
        /// This code snippet illustrates how to print 
        /// from the Amyuni PDF Converter using the printer object
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintText_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Printing text";
            
            //Declare object
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();

            //Initialize printer
            PDF.DriverInit(PDFprinter);

            PDF.DefaultFileName = getSampleWorkingDirectory() + "Resulting_Docs\\print_text.pdf";
           

            //Change some printer settings
            PDF.PaperSize = 1;			// letter
            PDF.Orientation = 1;		// portrait
            PDF.HorizontalMargin = 0;
            PDF.VerticalMargin = 0;
            PDF.Resolution = 1200;
            PDF.ImageOptions = 1;		// no duplicates

            //need to call this to apply changes
            PDF.SetDefaultConfigEx();

            PDF.FileNameOptionsEx = (int) sNoPrompt +  sUseFileName;


            string currentPrinter = printDocument1.PrinterSettings.PrinterName;

            printDocument1.PrinterSettings.PrinterName = PDFprinter;

            //This function needs to be called right before each print job
            PDF.EnablePrinter(strLicenseTo, strActivationCode);

            //Print something
            printDocument1.Print();


            PDF.FileNameOptions = 0;
            printDocument1.PrinterSettings.PrinterName = currentPrinter;

            lblPagePrint.Text = "Finished Printing text";

        }

        private void mySample()
        {
            MessageBox.Show("Hello");
        }


        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string text = "Amyuni Technologies";
             System.Drawing.Font printFont = new System.Drawing.Font
         	  ("Monotype Corsiva", 35, System.Drawing.FontStyle.Italic);

            // Draw the content.
            e.Graphics.DrawString(text, printFont, 
            	System.Drawing.Brushes.Black, 10, 10);
            Brush brish = new SolidBrush(System.Drawing.Color.Black);

            Image img = Image.FromFile(getSampleWorkingDirectory() + "Source_Docs\\Desert.jpg");


            //print image
             RectangleF imgRect = new RectangleF(50, 300, 400, 400);
             e.Graphics.DrawImage(img, imgRect);
 

        }



        /// <summary>
        /// Export PDF document to RTF
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExportToRtf_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Exporting to RTF....";
            
            //create Document object
            CDIntfEx.Document PDFdoc = new CDIntfEx.DocumentClass();

            try
            {
                //Need to set License information
                PDFdoc.SetLicenseKey(strLicenseTo, strActivationCode);

                //Open PDF file to convert into RTF format
                PDFdoc.OpenEx(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf", "");


                /*
                 Optimization Level OptimizeLevel value
                 No optimization                    0
                 Line optimization (Recommended)    1
                 Paragraph optimization              2
                 */
                PDFdoc.Optimize(1);


                /*
                    acRtfExportOptionAdvancedRTF Using frames to position objects 0x0000
                    acRtfExportOptionFullRTF Text, Graphics, and images with no frames 0x0001
                    acRtfExportOptionRTFText Formatted text only 0x0002
                    acRtfExportOptionText Simple, non-formated text 0x0003
                 */

                PDFdoc.ExportToRTF(getSampleWorkingDirectory() + "Resulting_Docs\\exporttortf.rtf", CDIntfEx.acRtfExportOptions.acRtfExportOptionAdvancedRTF, 0);

                MessageBox.Show("Document Converted", "Amyuni Sample", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Amyuni Sample", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }

            lblPagePrint.Text = "Finished Exporting to RTF";
        }

        

        /// <summary>
        /// Print MsWord Docs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintWord_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Going to Print MsWord Docs";

            //Declare object
            CDIntfEx.CDIntfEx PDF = new CDIntfEx.CDIntfExClass();

            //Initialize Printer
            PDF.DriverInit(PDFprinter);

            //set FileName for resulting PDF document
            PDF.DefaultFileName = getSampleWorkingDirectory() + "Resulting_Docs\\print_word.pdf";
            PDF.FileNameOptionsEx = (int)(sNoPrompt + sUseFileName);

            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);

            //Print to Word
            PrintToMsWord(getSampleWorkingDirectory() + "Source_Docs\\batchconvert.doc");

            PDF.FileNameOptions = 0;
            PDF.DriverEnd();
            lblPagePrint.Text = "..Printed MsWord Docs";
        }

        public void PrintToMsWord(string strFileName)
        {
            object oMissing = System.Reflection.Missing.Value;

            //Start Word and open the test document.
            Microsoft.Office.Interop.Word._Application oWord;
            Microsoft.Office.Interop.Word._Document oDoc;
            oWord = new Microsoft.Office.Interop.Word.Application();
            oWord.Visible = false;
            object oPath;

            string strSaveActivePrinter;

            //Save active printer
            strSaveActivePrinter = oWord.ActivePrinter;

            //assign word a printer
            oWord.ActivePrinter = PDFprinter;
            oPath = strFileName.ToString();

            oDoc = oWord.Documents.Open(ref oPath,
                ref oMissing, ref oMissing, ref oMissing,
                ref oMissing, ref oMissing, ref oMissing,
                ref oMissing, ref oMissing,
                ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                ref oMissing, ref oMissing, ref oMissing);

            //print it
            object xcopies = 1;
            object xpt = false;
            object oFalse = false;

            oDoc.PrintOut(ref xpt, ref oMissing, ref oMissing,
                ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref 
				xcopies, ref oMissing, ref oMissing, ref oMissing, ref 
				oMissing, ref oMissing, ref oMissing, ref oMissing, ref 
				oMissing, ref oMissing, ref oMissing);



            //close the document
            oDoc.Close(ref oFalse, ref oMissing, ref oMissing);

            oWord.Options.SaveNormalPrompt = false;
            oWord.Options.SavePropertiesPrompt = false;
            oWord.NormalTemplate.Saved = true;

            //restore active printer
            oWord.ActivePrinter = strSaveActivePrinter;

            //close word
            oWord.Quit(ref oFalse, ref oMissing, ref oMissing);

            //Drop our reference to the COM object
            Marshal.ReleaseComObject(oWord);

            oDoc = null;
            oWord = null;
        }


        /// <summary>
        /// Export PDF document into TIFF
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExportTiff_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Exporting to TIFF";
            
            CDIntfEx.Document PDFdoc = new CDIntfEx.DocumentClass();

            try
            {
                PDFdoc.SetLicenseKey(strLicenseTo, strActivationCode);
                PDFdoc.OpenEx(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf", "");

                PDFdoc.Optimize(2);
                PDFdoc.ExportToTIFF(getSampleWorkingDirectory() + "Resulting_Docs\\exporttotif.tif", CDIntfEx.acTiffExportOptions.acTiffExportOptionCCITTHigh);

                MessageBox.Show("Document Converted", "Amyuni Sample", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Amyuni Sample", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }

            lblPagePrint.Text = "Finished Exporting to TIFF";
        }
        /// <summary>
        /// Print XLS file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintExcel_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Going to Print Excel Docs";
            
            CDIntfEx.CDIntfEx PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);
            PDF.DefaultFileName = getSampleWorkingDirectory() + "Resulting_Docs\\print_excel.pdf";
            PDF.FileNameOptionsEx = (int)(sNoPrompt + sUseFileName + iConcat);  //1 + 2 + 4;

            PDF.SetDefaultPrinter();
            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);

            PrintExcel(getSampleWorkingDirectory() + "Source_Docs\\test.xls");


            PDF.RestoreDefaultPrinter();
            PDF.FileNameOptions = 0;
            PDF.DriverEnd();

            lblPagePrint.Text = "..Printed Excel Docs";
        }

        public void AmyuniBeginPage(int nJobID, int hDC)
        {
            lblPagePrint.Text = "Page printed";
        }


        /// <summary>
        /// Append Docs
        /// </summary>
        private void btnAppend_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Appending PDF documents";
            
            bool bResult;
            CDIntfEx.Document PDFDoc = new CDIntfEx.DocumentClass();
            PDFDoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);
            try
            {
                bResult = PDFDoc.OpenEx(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf", "");
                if (bResult == true)
                {
                    bool bResultAppend;
                    bResultAppend = PDFDoc.Append(getSampleWorkingDirectory() + "Source_Docs\\logo.pdf");

                    if (bResultAppend == true)
                    {
                        bool bResultSave;
                        bResultSave = PDFDoc.Save(getSampleWorkingDirectory() + "Resulting_Docs\\append.pdf");
                        if (bResultSave == true)
                        {
                            MessageBox.Show(bResult.ToString(), "Append Error Save");
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(bResult.ToString(), "Append Error Append");
                    }
                }
                else
                {
                    MessageBox.Show(bResult.ToString(), "Append Error Open ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Append Error Crash");
            }

            lblPagePrint.Text = "Finished Appending PDF documents";
        }

        /// <summary>
        /// Print existing PDF document
        /// The Print method can be used to print a PDF document to a hardware printer. It is also used to print 
        /// multiple pages on a single sheet of paper.This method is available only in the professional 
        /// version of the Amyuni PDF Converter product.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintPDFDoc_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Printing PDF document";
            
            CDIntfEx.Document PDFDoc = new CDIntfEx.DocumentClass();

            try
            {
                PDFDoc.OpenEx(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf", "");

                PDFDoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);
                
                //Parameters
                    //PrinterName
                        //[in] Name of printer as it shows in the printers control panel. 
                        //If this parameter is left empty, the document will print to the default printer
                    //StartPage
                        //[in] Page number from which to start printing. The index of the first page is 1
                    //EndPage
                        //[in] Page number at which to stop printing
                    //Copies
                        //[in] Number of copies to print the document

                PDFDoc.Print("", 1, PDFDoc.PageCount(), 1);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            lblPagePrint.Text = "Finished Printing PDF document";
        }


        public void PrintWaterMark()
        {
            CDIntfEx.Document oDoc = new CDIntfEx.DocumentClass();
            oDoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);
            oDoc.Open(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf");
            int nPageCount = oDoc.PageCount();

            oDoc.Print("", 1, nPageCount, 1);
        }


        /// <summary>
        /// Encrypt document at run-time
        /// The Encryption property can be used to password protect a PDF document and restrict 
        /// users to viewing, modifying or evenprinting the document.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEncrypt_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "";

            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);

            PDF.DefaultFileName = getSampleWorkingDirectory() + "Resulting_Docs\\encrypt.pdf";

            PDF.SetDefaultPrinter();


            /*////////////////////////////////////////////////////////////
            'Permission                         Permission value
            'Enable Printing                        - 64 + 4
            'Enable document modification           - 64 + 8
            'Enable copying text and graphics       - 64 + 16
            'Enable adding and changing notes       - 64 + 32
            'To combine multiple options, use -64 plus the values 4, 8, 16 or 32. E.g. to enable */

            //1 = 40-bit encryption
            //2 = 128-bit encryption

            PDF.Encryption = 2;
            PDF.OwnerPassword = "aaaaaa";
            PDF.UserPassword = "bbbbbb";
            PDF.Permissions = (-64 + 4);
            PDF.SetDefaultConfig();


            PDF.FileNameOptionsEx = (int)sNoPrompt + sUseFileName;
            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);

            //Print something
            printDocument1.Print();
            
            //Reset
            PDF.Encryption = 0;
            PDF.SetDefaultConfig();

            PDF.RestoreDefaultPrinter();
            PDF.FileNameOptions = 0;

            lblPagePrint.Text = "Document Encrypted!";

        }


        /// <summary>
        /// Print XLS documents
        /// </summary>
        /// <param name="strFileName"></param>
        public void PrintExcel(string strFileName)
        {
            object oMissing = System.Reflection.Missing.Value;
            //Start Excel and open test doc
            Microsoft.Office.Interop.Excel._Application oExcel;
            Microsoft.Office.Interop.Excel.Workbook wbExcel;


            string oPath;
            oPath = strFileName.ToString();


            oExcel = new Microsoft.Office.Interop.Excel.Application();
            oExcel.Visible = false;
            //oExcel.ActivePrinter = PDFprinter;


            wbExcel = oExcel.Workbooks.Open(
                oPath.ToString(),
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing);


            wbExcel.PrintOut(
                Missing.Value,  //From
                Missing.Value,  //To
                1,   //Copies
                Missing.Value,  //Preview
                Missing.Value,  //ActivePrinter
                Missing.Value,  //PrinToFile
                Missing.Value,  //Collate
                Missing.Value   //,PrToFileName
                );

            wbExcel.Close(false, //SaveChanges
                Missing.Value,//FileName
                Missing.Value //RouteWorkbook
                );

        }



        /// <summary>
        /// Export existing PDF document into HTML format
        /// </summary>
        private void btnExportToHtml_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Exporting to HTML";
            
            CDIntfEx.Document PDFdoc = new CDIntfEx.DocumentClass();

            try
            {

                PDFdoc.OpenEx(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf", "");

                PDFdoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);
                PDFdoc.Optimize(1);

                PDFdoc.ExportToHTML(getSampleWorkingDirectory() + "Resulting_Docs\\exporttohtml.htm", CDIntfEx.acHtmlExportOptions.acHtmlExportOptionSinglePage);

                MessageBox.Show("Document Converted", "Amyuni Sample", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Amyuni Sample", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }

            lblPagePrint.Text = "Finished Exporting to HTML";
        }


        /// <summary>
        /// Print a document into RTF format
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintRTF_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "";
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);  //Amyuni PDF Converter

            /*			PDF.VerticalMargin = 0;
                        PDF.HorizontalMargin = 0;
                        PDF.SetDefaultConfig ();
            */
            PDF.DefaultFileName = getSampleWorkingDirectory() + "Source_Docs\\print_rtf.pdf";

            /*/////////////////////////////////////////////////////////////
            'RTF Format Integer Option for formatting the RTF output
            '0 � Advanced RTF
            '1 � Full RTF
            '2 � Formatted Text
            '3 � Non-formatted Text Only
            'Example: PDF.PrinterParamInt("RTF Format") = 1

            '////////////////////////////////////////////////////////////
            'Use Tabs Integer Option to replace tabs by spaces
            '0 � Do not replace
            '1 � Replace
            'Example: PDF.PrinterParamInt("Use Tabs") = 0
            */

            PDF.SetPrinterParamInt("RTF Format", 1);
            PDF.SetPrinterParamInt("Use Tabs", 0);

            PDF.FileNameOptionsEx = (int)sNoPrompt + sUseFileName + lExportToRtf;

            PDF.SetDefaultPrinter();
            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);

            //Print something
            printDocument1.Print();

            PDF.RestoreDefaultPrinter();
            PDF.FileNameOptionsEx = 0;
            PDF.DriverEnd();

            lblPagePrint.Text = "Printed into RTF";
        }



        /// <summary>
        /// Export PDF document into JPEG image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExportToJPEG_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Exporting to JPEG";

            CDIntfEx.Document PDFdoc = new CDIntfEx.DocumentClass();
            try
            {
                PDFdoc.OpenEx(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf", "");
                PDFdoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);

                /*  'No optimization 0
                    'Line optimization (Recommended) 1
                    'Paragraph optimization 2
                */
                PDFdoc.Optimize(1);

                PDFdoc.ExportToJPEG(getSampleWorkingDirectory() + "Resulting_Docs\\exporttojpg.jpg", CDIntfEx.acJPegExportOptions.acJPegExportOptionMedium);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            lblPagePrint.Text = "Finished Exporting to JPEG";
        }

        private void btnChangeProperties_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Change PDF documents Attributes";
            
            CDIntfEx.Document PDFdoc = new CDIntfEx.DocumentClass();
            try
            {
                PDFdoc.Open(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf");
                PDFdoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);

                PDFdoc.Author = "Bill Smith";
                PDFdoc.Subject = "Test Doc";
                PDFdoc.KeyWords = "add keywords";
                PDFdoc.Creator = "my product";
                PDFdoc.Title = "this is the document title";

                PDFdoc.Save(getSampleWorkingDirectory() + "Resulting_Docs\\ChangeProperties.pdf");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            lblPagePrint.Text = "Finished Changing PDF documents Attributes";
        }


        /// <summary>
        /// Export existing PDF into XLS format
        /// </summary>
        private void btnExportToExcel_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Exporting to XLS";
            
            CDIntfEx.Document PDFdoc = new CDIntfEx.DocumentClass();
            try
            {
                PDFdoc.Open(getSampleWorkingDirectory() + "Source_Docs\\fivepages.pdf");
                PDFdoc.SetLicenseKey(txtLicenseTo.Text, txtActivationCode.Text);

                /*  'No optimization 0
                    'Line optimization (Recommended) 1
                    'Paragraph optimization 2
                */
                PDFdoc.Optimize(1);
                PDFdoc.ExportToEXCEL(getSampleWorkingDirectory() + "Resulting_Docs\\\from_c_sharp.xls", CDIntfEx.acExcelExportOptions.acExcelExportOptionMultipleSheets);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            lblPagePrint.Text = "Finished Exporting to XLS";
        }

        /// <summary>
        /// The BatchConvert method converts a number of files to PDF, RTF, HTML, Excel or JPeg formats in batch mode.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBatchConvert_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "....";
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);  //Amyuni PDF Converter

            PDF.SetDefaultPrinter();
            PDF.DefaultDirectory = getSampleWorkingDirectory() + "Resulting_Docs\\";


            PDF.FileNameOptionsEx = (int)sNoPrompt;

            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);

            /*The Document Converter printer should be configured with the destination file name and all other 
             * options before calling this function. The printer should also be set as default printer. 
             * This function launches the application that is associated with a specific file and issues a print 
             * command to convert the document.*/

            PDF.BatchConvert(getSampleWorkingDirectory() + "Source_Docs\\*.doc");


            PDF.RestoreDefaultPrinter();
            PDF.FileNameOptions = 0;

            lblPagePrint.Text = "BatchConvert";
        }



        /// <summary>
        /// Print document into TIFF format
        /// </summary>    
        private void btnPrintTFF_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "....";
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);  //Amyuni PDF Converter

            PDF.DefaultFileName = getSampleWorkingDirectory() + "Resulting_Docs\\print_tiff.pdf";

            /*///////////////////////////////////////
            'Custom parameters for the TIFF Converter:
            'Parameter Type Description Values
            'TIFF Resolution: Integer Image resolution at which the document
            'is converted to JPeg
            '0 � 75 DPI
            '1 � 150 DPI
            '2 � 300 DPI
            '3 � 600 DPI
            'TIFF Options: Integer TIFF compression level.
            '0 � No TIFF Output
            '16 � TIFF output with no compression
            '26 � TIFF output with CCITT Fax Compression
            '17 to 25 JPEG Compression values. Note: Not supported by all tiff viewers
            '(17 = 1 to 25 = 9)
            ///////////////////////////////////////////*/
            PDF.SetPrinterParamInt("TIFF Options", 26);
            PDF.SetPrinterParamInt("TIFF Resolution", 1);


            PDF.FileNameOptionsEx = (int)sNoPrompt + sUseFileName;

            PDF.SetDefaultPrinter();
            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);

            //Print something
            printDocument1.Print();

            PDF.RestoreDefaultPrinter();
            PDF.FileNameOptionsEx = 0;
            PDF.DriverEnd();

            lblPagePrint.Text = "Printed into TIFF";

        }


        /// <summary>
        /// Print into XLS format
        /// </summary>
        private void btnPrintExportToExcel_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "....";
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);  //Amyuni PDF Converter

            PDF.DefaultFileName = getSampleWorkingDirectory() + "Source_Docs\\print_excel.pdf";


            PDF.FileNameOptionsEx = (int)sNoPrompt + sUseFileName;

            //PDF.SetPrinterParamInt("EXCEL MultiSheets",18);   ' // Single Excel sheet with comma separator
            //PDF.SetPrinterParamInt("EXCEL MultiSheets", 17);    ' // MultiSheets Excel sheet
            //PDF.SetPrinterParamInt("EXCEL MultiSheets",19;)    ' // MultiSheets Excel sheet with comma separator
            PDF.SetPrinterParamInt("EXCEL MultiSheets", 16);


            PDF.SetDefaultPrinter();

            PDF.EnablePrinter(txtLicenseTo.Text, txtActivationCode.Text);
            //Print something
            printDocument1.Print();

            PDF.RestoreDefaultPrinter();
            PDF.FileNameOptionsEx = 0;
            PDF.DriverEnd();

            lblPagePrint.Text = "Printed into XLS";
        }


        /// <summary>
        /// Print PPT Docs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintPowerPoint_Click(object sender, System.EventArgs e)
        {
            lblPagePrint.Text = "Going to Print PowerPoint Docs";
            
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);
            PDF.DefaultFileName = PDF.DefaultFileName = getSampleWorkingDirectory() + "Resulting_Docs\\PowerPoint.pdf";

            PDF.SimPostscript = true;
            PDF.SetDefaultConfig();

            PDF.FileNameOptionsEx = (int)(sNoPrompt + sUseFileName);

            PDF.EnablePrinter(strLicenseTo, strActivationCode);
            PrintPowerPoint(getSampleWorkingDirectory() + "Source_Docs\\powerpoint.ppt");

            PDF.FileNameOptions = 0;

            lblPagePrint.Text = "..Printed Excel Docs";
        }


        /// <summary>
        /// Print PPT docs
        /// </summary>
        /// <param name="strFileName"></param>
        public void PrintPowerPoint(string strFileName)
        {
            
            Microsoft.Office.Interop.PowerPoint._Application objApp;
            Microsoft.Office.Interop.PowerPoint.Presentations objPresSet;
            Microsoft.Office.Interop.PowerPoint._Presentation objPres;

            try
            {
                //Create a new presentation 
                objApp = new Microsoft.Office.Interop.PowerPoint.Application ();
                objPresSet = objApp.Presentations;


                objPres = objPresSet.Open(strFileName.ToString(),
                    Microsoft.Office.Core.MsoTriState.msoFalse, Microsoft.Office.Core.MsoTriState.msoTrue,
                    Microsoft.Office.Core.MsoTriState.msoFalse);


                //store active printer
                string pptActivePrinter = objPres.PrintOptions.ActivePrinter;
                objPres.PrintOptions.ActivePrinter = PDFprinter;

                objPres.PrintOut(1, 1, "", 1, Microsoft.Office.Core.MsoTriState.msoFalse);

                //restore active printer
                objPres.PrintOptions.ActivePrinter = pptActivePrinter;

                //Close the presentation
                objPres.Close();
                objApp.Quit();

            }
            catch (Exception theException)
            {
                String errorMessage;
                errorMessage = "Error: ";
                errorMessage = String.Concat(errorMessage, theException.Message);
                errorMessage = String.Concat(errorMessage, " Line: ");
                errorMessage = String.Concat(errorMessage, theException.Source);

                MessageBox.Show(errorMessage, "Error");
            }
        }


   
         /// <summary>
        /// This code snippet uses Threading to illstrutate the
        /// Lock/Unlock functionality of the PDF Converter.
        /// The Lock function can be used in multi-threading situations to avoid conflicts between 
        /// multiple applications or multiple threads requesting simultaneous access the Converter products. 
        /// The CDIntf library uses the registry to interact with the printer drivers.
        ///This can cause conflicts when multiple applications use CDIntf to access the printer drivers.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnThread_Click(object sender, EventArgs e)
        {
            lblPagePrint.Text = "Start Threading";
            Thread demoThread  =
                new Thread(new ThreadStart(this.thread_printing));

           demoThread.Start();
           lblPagePrint.Text = "End Threading";
        }

        
        /// <summary>
        /// Lock/Unlock Functions
        /// </summary>
        private void thread_printing()
        {
            CDIntfEx.CDIntfExClass PDF = new CDIntfEx.CDIntfExClass();
            PDF.DriverInit(PDFprinter);  

            //Need to use distinct doc names
            string docTitle = "amy" + DateTime.UtcNow.Millisecond.ToString();
            printDocument1.DocumentName = docTitle;

            PDF.Lock (docTitle);

            PDF.SetDocFileProps(docTitle, 3, "", getSampleWorkingDirectory() + "Resulting_Docs\\" + docTitle + ".pdf"); 
            
            PDF.EnablePrinter(strLicenseTo, strActivationCode);

             //Print something
             printDocument1.Print();
             PDF.Unlock(docTitle, 1000);

        }

    }
}
