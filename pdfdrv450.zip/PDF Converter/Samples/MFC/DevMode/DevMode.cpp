// DevMode.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "DevMode.h"
#include "DevModeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDevModeApp

BEGIN_MESSAGE_MAP(CDevModeApp, CWinApp)
	//{{AFX_MSG_MAP(CDevModeApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDevModeApp construction

CDevModeApp::CDevModeApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDevModeApp object

CDevModeApp theApp;

#define LICENSE_TO				"Amyuni Tech Evaluation"
#define ACTIVATION_CODE			"07EFCDAB01000100AC41A4BA0E46B16F7B4436B737C321BECEB38B37B26EA0FCA05A08CD6C65271D1C1575F7C6F139E75182B855A5D1"
#define AMYUNI_PRINTER_NAME		 "Amyuni PDF Converter"

/////////////////////////////////////////////////////////////////////////////
// CDevModeApp initialization

BOOL CDevModeApp::InitInstance()
{
	AfxEnableControlContainer();

	//Attached to existing PDF Converter
	//Use the same printer name as what you find in the 
	//control panel
	m_converter = ::DriverInit(AMYUNI_PRINTER_NAME);
	if ( NULL == m_converter )
	{
		return false;
	}

	::CDISetDefaultPrinter  ( m_converter );
	::SetFileNameOptions ( m_converter, 3);
	::SetDefaultFileName(m_converter, "c:\\temp\\amyuni.pdf");

	// set the license information
	::EnablePrinter (m_converter,LICENSE_TO, ACTIVATION_CODE);

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CDevModeDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
int CDevModeApp::ExitInstance() 
{
	// close printer handle; this will also restore the default printer
	if ( NULL != m_converter )
	{
		::RestoreDefaultPrinter ( m_converter );
		::DriverEnd( m_converter );
	}
	
	return CWinApp::ExitInstance();
}
