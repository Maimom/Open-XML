// DevModeDlg.h : header file
//

#if !defined(AFX_DEVMODEDLG_H__2A0715FF_54F6_435D_8612_3B66378749B1__INCLUDED_)
#define AFX_DEVMODEDLG_H__2A0715FF_54F6_435D_8612_3B66378749B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDevModeDlg dialog

class CDevModeDlg : public CDialog
{
// Construction
public:
	bool TestDevMode();
	CDevModeDlg(CWnd* pParent = NULL);	// standard constructor
	HANDLE	m_hPrinter;

// Dialog Data
	//{{AFX_DATA(CDevModeDlg)
	enum { IDD = IDD_DEVMODE_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	enum AMYUNI_DEVMODE_FLAGS
	{
			DM_FLAT_COMPRESSION = 0x00000001,
			DM_EMBED_FONTS = 0x00000002,
			DM_JPEG_COMPRESSION = 0x00000004,
			DM_256_COLOUR_COMPRESSION = 0x00000008,
			DM_BROADCAST_MESSAGES = 0x00000010,
			DM_MULTILINGUAL_SUPPORT = 0x00000020,
			DM_FULL_EMBEDDING = 0x00000040,
			DM_EMBED_STANDARD_FONTS = 0x00000080,
			DM_LICENSED_EMBEDDING = 0x00000100,
	};


	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDevModeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDevModeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnDevmode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEVMODEDLG_H__2A0715FF_54F6_435D_8612_3B66378749B1__INCLUDED_)
