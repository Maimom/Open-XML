// IDS.H

#define	IDM_THREAD	100
#define	IDM_HELP	101
#define	IDM_EXIT	102
