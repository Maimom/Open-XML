//THREAD.H

//This is the main window class
#include <string.h>

class CMainWIn : public CFrameWnd
{
public:

	int m_x, m_y; //current output location
	CDC m_memDC; // virtual window device context
	CBitmap m_bmp; //virtual window bitmap
	CBrush m_bkbrush; //brush for virtual window

	CMainWIn();

	afx_msg void OnPaint();
	afx_msg void OnLButtonDown (UINT Flags, CPoint Loc);

	afx_msg void OnThread();
	afx_msg void OnExit();
	afx_msg void OnHelp();

	DECLARE_MESSAGE_MAP ()
};

//This is the applicaiton class
class CApp : public CWinApp
{
public:
	BOOL InitInstance();
};