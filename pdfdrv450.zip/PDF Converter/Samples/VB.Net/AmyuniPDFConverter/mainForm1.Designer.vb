﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainForm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.btnPrintMsWord = New System.Windows.Forms.Button
        Me.btnPrintSendByEmail = New System.Windows.Forms.Button
        Me.btnPrintText = New System.Windows.Forms.Button
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.btnPrint = New System.Windows.Forms.Button
        Me.btnSearchText = New System.Windows.Forms.Button
        Me.btnHyperLinks = New System.Windows.Forms.Button
        Me.btnEncrypt = New System.Windows.Forms.Button
        Me.btnMerge = New System.Windows.Forms.Button
        Me.btnAppendMultipleDocs = New System.Windows.Forms.Button
        Me.btnAppend = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(32, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(360, 248)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnPrintMsWord)
        Me.TabPage1.Controls.Add(Me.btnPrintSendByEmail)
        Me.TabPage1.Controls.Add(Me.btnPrintText)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(273, 222)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "CdintfEx"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnPrintMsWord
        '
        Me.btnPrintMsWord.Location = New System.Drawing.Point(20, 96)
        Me.btnPrintMsWord.Name = "btnPrintMsWord"
        Me.btnPrintMsWord.Size = New System.Drawing.Size(139, 23)
        Me.btnPrintMsWord.TabIndex = 2
        Me.btnPrintMsWord.Text = "Print MsWord"
        Me.btnPrintMsWord.UseVisualStyleBackColor = True
        '
        'btnPrintSendByEmail
        '
        Me.btnPrintSendByEmail.Location = New System.Drawing.Point(20, 57)
        Me.btnPrintSendByEmail.Name = "btnPrintSendByEmail"
        Me.btnPrintSendByEmail.Size = New System.Drawing.Size(139, 23)
        Me.btnPrintSendByEmail.TabIndex = 1
        Me.btnPrintSendByEmail.Text = "Print SendByEmail"
        Me.btnPrintSendByEmail.UseVisualStyleBackColor = True
        '
        'btnPrintText
        '
        Me.btnPrintText.Location = New System.Drawing.Point(20, 19)
        Me.btnPrintText.Name = "btnPrintText"
        Me.btnPrintText.Size = New System.Drawing.Size(139, 23)
        Me.btnPrintText.TabIndex = 0
        Me.btnPrintText.Text = "Print Text"
        Me.btnPrintText.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btnPrint)
        Me.TabPage2.Controls.Add(Me.btnSearchText)
        Me.TabPage2.Controls.Add(Me.btnHyperLinks)
        Me.TabPage2.Controls.Add(Me.btnEncrypt)
        Me.TabPage2.Controls.Add(Me.btnMerge)
        Me.TabPage2.Controls.Add(Me.btnAppendMultipleDocs)
        Me.TabPage2.Controls.Add(Me.btnAppend)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(352, 222)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Document Object"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(190, 54)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(139, 23)
        Me.btnPrint.TabIndex = 6
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnSearchText
        '
        Me.btnSearchText.Location = New System.Drawing.Point(190, 15)
        Me.btnSearchText.Name = "btnSearchText"
        Me.btnSearchText.Size = New System.Drawing.Size(139, 23)
        Me.btnSearchText.TabIndex = 5
        Me.btnSearchText.Text = "SearchText"
        Me.btnSearchText.UseVisualStyleBackColor = True
        '
        'btnHyperLinks
        '
        Me.btnHyperLinks.Location = New System.Drawing.Point(24, 168)
        Me.btnHyperLinks.Name = "btnHyperLinks"
        Me.btnHyperLinks.Size = New System.Drawing.Size(139, 23)
        Me.btnHyperLinks.TabIndex = 4
        Me.btnHyperLinks.Text = "HyperLinks"
        Me.btnHyperLinks.UseVisualStyleBackColor = True
        '
        'btnEncrypt
        '
        Me.btnEncrypt.Location = New System.Drawing.Point(24, 130)
        Me.btnEncrypt.Name = "btnEncrypt"
        Me.btnEncrypt.Size = New System.Drawing.Size(139, 23)
        Me.btnEncrypt.TabIndex = 3
        Me.btnEncrypt.Text = "Encrypt"
        Me.btnEncrypt.UseVisualStyleBackColor = True
        '
        'btnMerge
        '
        Me.btnMerge.Location = New System.Drawing.Point(24, 92)
        Me.btnMerge.Name = "btnMerge"
        Me.btnMerge.Size = New System.Drawing.Size(139, 23)
        Me.btnMerge.TabIndex = 2
        Me.btnMerge.Text = "Merge"
        Me.btnMerge.UseVisualStyleBackColor = True
        '
        'btnAppendMultipleDocs
        '
        Me.btnAppendMultipleDocs.Location = New System.Drawing.Point(24, 54)
        Me.btnAppendMultipleDocs.Name = "btnAppendMultipleDocs"
        Me.btnAppendMultipleDocs.Size = New System.Drawing.Size(139, 23)
        Me.btnAppendMultipleDocs.TabIndex = 1
        Me.btnAppendMultipleDocs.Text = "Append Multiple Docs"
        Me.btnAppendMultipleDocs.UseVisualStyleBackColor = True
        '
        'btnAppend
        '
        Me.btnAppend.Location = New System.Drawing.Point(24, 16)
        Me.btnAppend.Name = "btnAppend"
        Me.btnAppend.Size = New System.Drawing.Size(139, 23)
        Me.btnAppend.TabIndex = 0
        Me.btnAppend.Text = "Append"
        Me.btnAppend.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(424, 27)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(244, 238)
        Me.ListBox1.TabIndex = 1
        '
        'PrintDocument1
        '
        '
        'mainForm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(704, 305)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "mainForm1"
        Me.Text = "Amyuni PDF Converter Sample App"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents btnPrintText As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents btnAppend As System.Windows.Forms.Button
    Friend WithEvents btnAppendMultipleDocs As System.Windows.Forms.Button
    Friend WithEvents btnMerge As System.Windows.Forms.Button
    Friend WithEvents btnEncrypt As System.Windows.Forms.Button
    Friend WithEvents btnHyperLinks As System.Windows.Forms.Button
    Friend WithEvents btnSearchText As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnPrintSendByEmail As System.Windows.Forms.Button
    Friend WithEvents btnPrintMsWord As System.Windows.Forms.Button

End Class
