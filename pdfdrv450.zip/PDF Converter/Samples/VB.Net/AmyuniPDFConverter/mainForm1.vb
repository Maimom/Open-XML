﻿Imports System.IO
Imports System.Text

Public Class mainForm1
    ' Constants for Activation codes
    Const strLicenseTo As String = "Amyuni Tech. Evaluation"
    Const strActivationCode As String = "07EFCDAB01000100DF6EFC8664508CC905BADA9A6C56066D8219C78B8804C5D09ECA85769789782B3945B0ECA66CB3612C5D7772F0B9"
    Const AMYUNI_PRINTER_NAME As String = "Amyuni PDF Converter"

    Dim PDF As CDIntfEx.CDIntfEx
    Dim PDFdoc As CDIntfEx.DocumentClass


    Const NoPropmt As Int32 = &H1&
    Const UseFileName As Int32 = &H2&
    Const Color256Compression As Int32 = &H800000&
    Const JPEGExport As Int32 = &H10000000&
    Const RTFExport As Int32 = &H8000000&
    Const SendByEmail As Int32 = &H800&
    Const JpegLevelLow As Int32 = &H20000&
    Const Jpeg2000Compression As Int32 = &H1000000&
	
	
    '///////////////////////////////////////////////////////////////////////
	'This method is only used to get the working directory of this sample project.
	'///////////////////////////////////////////////////////////////////////
    Private Function GetWorkingDirectory()
        Dim currentDirectory As String = System.IO.Directory.GetCurrentDirectory()
        Dim directories() As String = currentDirectory.Split(Path.DirectorySeparatorChar)

        Dim strWorkingPath As New StringBuilder

        If (directories(0) IsNot Nothing) Then

            For Each direc As String In directories
                strWorkingPath.Append(direc & "\\")

                If String.Compare(direc, "AmyuniPDFConverter", StringComparison.OrdinalIgnoreCase) = 0 Then
                    Return strWorkingPath.ToString()
                End If

            Next

        End If


        Return ""

    End Function



    '///////////////////////////////////////////////////////////////////////
    'This code snippet illustrates how to print to the Amyuni PDF Converter
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnPrintText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintText.Click

        'Declare a new cdintfex object
        PDF = New CDIntfEx.CDIntfEx

        'Get a reference to the installed printer.
        'This will fail if the printer name passed to the DriverInit method is not found in the printer’s folder
        PDF.DriverInit(AMYUNI_PRINTER_NAME)

        'Resulting PDF document stored here
        PDF.DefaultFileName = GetWorkingDirectory.ToString() & "Resulting_PDFs\\PrintText_resulting.pdf"

        'set printer options
        PDF.FileNameOptions = NoPropmt + UseFileName

        Dim currentPrinter As String = PrintDocument1.PrinterSettings.PrinterName
        PrintDocument1.PrinterSettings.PrinterName = AMYUNI_PRINTER_NAME

        'The EnablePrinter()method needs to be called right before each print job. 
        'Calling the EnablePrinter()method will start a 20 second time-out value
        PDF.EnablePrinter(strLicenseTo, strActivationCode)

        'Print(something)
        PrintDocument1.Print()

        PrintDocument1.PrinterSettings.PrinterName = currentPrinter

        'Clean(-up)
        PDF.FileNameOptions = 0

        ListBox1.Items.Add("PrintText_resulting.pdf .... created")

    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Try

            ' Turn on antialias for text
            e.Graphics.TextRenderingHint = _
                             Drawing.Text.TextRenderingHint.AntiAlias
            ' Print a string at the origin
            Dim pFont As Font
            pFont = New Font("Comic Sans MS", 20)
            e.Graphics.DrawString("Amyuni PDF Converter", pFont, Brushes.Black, 0, 0)

            ' Read margins into local variables
            Dim Lmargin, Rmargin, Tmargin, BMargin As Integer
            With PrintDocument1.DefaultPageSettings.Margins
                Lmargin = .Left
                Rmargin = .Right
                Tmargin = .Top
                BMargin = .Bottom
            End With

            ' Calculate the dimensions of the printable area
            Dim PrintWidth, PrintHeight As Integer
            With PrintDocument1.DefaultPageSettings.PaperSize
                PrintWidth = .Width - Lmargin - Rmargin
                PrintHeight = .Height - Tmargin - BMargin
            End With

            ' Now print the rectangle
            Dim R As Rectangle
            R = New Rectangle(Lmargin, Tmargin, PrintWidth, PrintHeight)
            e.Graphics.DrawRectangle(Pens.Black, R)

            Dim img As Image = Image.FromFile(GetWorkingDirectory.ToString() & "Source_docs\\Penguins.jpg")
            Dim rect As Rectangle = New Rectangle(100, 100, 50, 50)
            e.Graphics.DrawImage(img, rect)


        Catch Exc As Exception
            'Catch and display errors
            MsgBox("Error Printing")
        End Try
    End Sub

    '///////////////////////////////////////////////////////////////////////
    'The Appen or AppendEx methods append or concatenate a second PDF file to a first one.
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnAppend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAppend.Click

        Dim pdfDoc As New CDIntfEx.Document

        Dim source_pdf_file_one As String = GetWorkingDirectory.ToString() & "Source_docs\\one.pdf"
        Dim source_pdf_file_two As String = GetWorkingDirectory.ToString() & "Source_docs\\two.pdf"

        Dim resulting_pdf_file As String = GetWorkingDirectory.ToString() & "Resulting_PDFs\\Append_resulting.pdf"

        'Open the main file ONLY once
        'This will improve performance because you will not
        'need to open the file at each iteration
        pdfDoc.Open(source_pdf_file_one)
        pdfDoc.Append(source_pdf_file_two)

        pdfDoc.Save(resulting_pdf_file)

        ListBox1.Items.Add("Append_resulting.pdf ...... created")

    End Sub




    '///////////////////////////////////////////////////////////////////////
    'The Appen or AppendEx methods append or concatenate a second PDF file to a first one.
    'This code snippet illustrates how to append a large number of documents
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnAppendMultipleDocs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAppendMultipleDocs.Click

        Dim pdfDoc As New CDIntfEx.Document
        Dim result As String = ""
        Dim result1 As String = ""
        Dim counter As Integer = 1

        Dim source_pdf_file As String = GetWorkingDirectory.ToString() & "Source_docs\\one.pdf"
        Dim resulting_pdf_file As String = GetWorkingDirectory.ToString() & "Resulting_PDFs\\AppendMultipleDocs_resulting.pdf"

        pdfDoc.Open(source_pdf_file)

        'Example:
        'Loop through a directory that has 1000 PDF documents
        Do
            result = Path.GetFileNameWithoutExtension(source_pdf_file)

            'This is much quicker because you don't need to open
            'the file
            pdfDoc.Append(GetWorkingDirectory.ToString() & "Source_docs\\" & result & counter & ".pdf")
            counter = counter + 1

        Loop Until counter = 3

        'Save when you are done
        pdfDoc.Save(resulting_pdf_file)

        ListBox1.Items.Add("AppendMultipleDocs_resulting.pdf ...... created")
    End Sub

    '///////////////////////////////////////////////////////////////////////
    'The Merge and MergeEx methods merge two PDF documents by combining the contents of every page 
    'of the first documentwith a page from the second document.
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnMerge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMerge.Click

        ' create two objects of type Document
        Dim pdfDoc_1 As New CDIntfEx.Document
        Dim pdfDoc_2 As New CDIntfEx.Document

        ' open the document containing the watermark
        pdfDoc_1.Open(GetWorkingDirectory.ToString() & "Source_docs\\one.pdf")

        ' open the main document
        pdfDoc_2.Open(GetWorkingDirectory.ToString() & "Source_docs\\logo.pdf")

        ' merge the watermark document to the main one
        'Repeat first pages = 1 
        'The first pages of the second document are repeated in the 
        'first(document)

        'Second document above first = 2 
        'The contents of the second document are printed above the contents of
        'the first document
        pdfDoc_1.MergeEx(pdfDoc_2, 1)

        ' save document to some other file
        pdfDoc_1.Save(GetWorkingDirectory.ToString() & "Resulting_PDFs\\Merge_resulting.pdf")

        ListBox1.Items.Add("Merge_resulting ...... created")

    End Sub



    '///////////////////////////////////////////////////////////////////////
    'The Encrypt and Encrypt128 methods can be used to password protect a PDF document and restrict users to viewing, 
    'modifying or even printing the document. This function requires a call to Document.SetLicenseKey before it can be used. 
    'The Encrypt method uses 40 bits encryption, whereas the Encrypt128 method uses 128 bits encryption compatible 
    'with Adobe® Acrobat® 5 and higher.
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnEncrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEncrypt.Click
        Dim PDFdoc As New CDIntfEx.Document

        PDFdoc.Open(GetWorkingDirectory.ToString() & "Source_docs\\one.pdf")
        PDFdoc.SetLicenseKey(strLicenseTo, strActivationCode)

        ' '/////////////////////////////////////////////////////////////
        ''Permission                         Permission value
        ''Enable Printing                        - 64 + 4
        ''Enable document modification           - 64 + 8
        ''Enable copying text and graphics       - 64 + 16
        ''Enable adding and changing notes       - 64 + 32
        ''To combine multiple options, use -64 plus the values 4, 8, 16 or 32. E.g. to enable
        ''&HFFFFF0C0

        PDFdoc.Encrypt("aaaaaa", "", -64)

        PDFdoc.Save(GetWorkingDirectory.ToString() & "Resulting_PDFs\\Encrypt_resulting.pdf")

        ListBox1.Items.Add("Encrypt_resulting ...... created")
    End Sub




    '///////////////////////////////////////////////////////////////////////
    'The SetHyperlinkURL method creates hyperlinks to external locations such as http://www.amyuni.com and
    'ftp://ftp.amyuni.com. When the document is opened and the hyperlink is clicked, 
    'the default web browser will be launched.
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnHyperLinks_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHyperLinks.Click
        Dim PDFdoc As New CDIntfEx.Document

        PDFdoc.Open(GetWorkingDirectory.ToString() & "Source_docs\\hyperlink.pdf")
        PDFdoc.SetLicenseKey(strLicenseTo, strActivationCode)

        'SetHyperLinkURL(ByVal PageNumber As Integer, 
        'ByVal xStart As Integer, 
        'ByVal yStart As Integer, 
        'ByVal xEnd As Integer, 
        'ByVal yEnd As Integer, 
        'ByVal URL As String) As Boolean

        'The SetHyperlinkURL method creates hyperlinks to external locations such as http://www.amyuni.com and
        'ftp://ftp.amyuni.com. When the document is opened and the hyperlink is clicked, the default 
        'web browser will be launched.

        'In this example the hyperlink will point another PDF document.
        PDFdoc.SetHyperLinkURL(1, 0, 0, 1000, 1000, "/S /Launch /F (c:/temp/pdf1.pdf)")

        'In this example the hyperlink will point a URL.
        PDFdoc.SetHyperLinkURL(2, 0, 0, 1000, 1000, "www.amyuni.com")

        PDFdoc.Save(GetWorkingDirectory.ToString() & "Resulting_PDFs\\HyperLinks_resulting.pdf")

        ListBox1.Items.Add("HyperLinks_resulting.pdf  ...... created")

    End Sub



    '///////////////////////////////////////////////////////////////////////
    'The searchText method is used to search for a specific text.It is less accurate in returning the text 
    'position but much faster than SearchTextEx. It only works with WinAnsi encoded streams, 
    'but not with other encodings.
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnSearchText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchText.Click
        Dim PDFDoc As New CDIntfEx.Document
        PDFDoc.SetLicenseKey(strLicenseTo, strActivationCode)
        Try
            PDFDoc.Open(GetWorkingDirectory.ToString() & "Source_docs\\one.pdf")

            Dim xPos As Double
            Dim yPos As Double
            Dim page As Integer
            Dim start As Short = 0
            Dim strFind As String

            strFind = "One"

            With PDFDoc
                If (.SearchTextEx(start, strFind, page, xPos, yPos)) Then
                    MessageBox.Show("Found text on page: " & page & " at X Position: " & xPos & " and at Y Position: " & yPos)
                End If
            End With

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        PDFDoc = Nothing
    End Sub


    '///////////////////////////////////////////////////////////////////////
    'This code snippet illustrates how to print a PDF document 
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim PDFDoc As New CDIntfEx.Document
        PDFDoc.SetLicenseKey(strLicenseTo, strActivationCode)
        Try

            PDFDoc.Open(GetWorkingDirectory.ToString() & "Source_docs\\one.pdf")

            With PDFDoc
                'Print function available in Pro version only
                'Print(PrinterName As String, StartPage As Long, EndPage As Long, Copies As Long)
                'PrinterName
                '    Name of printer as it shows in the printers control panel.
                '    If this parameter is left empty, the document will print to the default printer.
                'StartPage
                '   Page number from which to start printing. The index of the first page is 1.
                'EndPage
                '   Page number at which to stop printing.
                'Copies
                '   Number of copies to print the document.
                '.Print "\\Server Name\Printer Name", 1, pdfDoc.PageCount, 1

                'Return code
                ' 0 is success
                ' -1 is a failure
                PDFDoc.Print("", 1, 1, 1)
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        PDFDoc = Nothing
    End Sub




    '///////////////////////////////////////////////////////////////////////
    'This code snippet illustrates how to automatically send the PDF document as an email 
    'attachment after the document is generated by the Amyuni PDF Converter.
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnPrintSendByEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintSendByEmail.Click
        Dim PDF As New CDIntfEx.CDIntfEx
        PDF.DriverInit(AMYUNI_PRINTER_NAME)

        'Set Email Options
        PDF.EmailFieldFrom = "foo@bar.com"
        PDF.EmailFieldTo = "foobar@foo.com"
        PDF.EmailSubject = "This is a PDF attachment"
        PDF.EmailMessage = "This is an email message body"
        PDF.EmailPrompt = True

        Dim strCurrentPrinter As String = PrintDocument1.PrinterSettings.PrinterName
        PrintDocument1.PrinterSettings.PrinterName = AMYUNI_PRINTER_NAME

        PDF.FileNameOptionsEx = NoPropmt + SendByEmail

        PDF.EnablePrinter(strLicenseTo, strActivationCode)
        'Print Something
        PrintDocument1.Print()


        PDF.FileNameOptionsEx = 0
        PrintDocument1.PrinterSettings.PrinterName = strCurrentPrinter

        ListBox1.Items.Add("Document sent by email  ....... ")
    End Sub


    '///////////////////////////////////////////////////////////////////////
    'This code snippet illustrates how print a MsWord document to the Amyuni PDF Converter
    '///////////////////////////////////////////////////////////////////////
    Private Sub btnPrintMsWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintMsWord.Click
        PDF = New CDIntfEx.CDIntfEx
        PDF.DriverInit(AMYUNI_PRINTER_NAME)

        'Create Word objects
        Dim PDFWord As New Microsoft.Office.Interop.Word.Application
        Dim MsDoc As Microsoft.Office.Interop.Word.Document

        With PDF

            .DefaultFileName = GetWorkingDirectory.ToString() & "Resulting_PDFs\\PrintMsWord_resulting.pdf"
            .FileNameOptionsEx = NoPropmt + UseFileName

        End With


        Try
            PDFWord.Visible = False
            'Get Word’s current active printer
            Dim currentPrinter As String = PDFWord.ActivePrinter

            'Set the PDF Converter as Word’s active printer. 
            'This  is more efficient than changing the system’s default printer
            PDFWord.ActivePrinter = (AMYUNI_PRINTER_NAME)

            PDF.EnablePrinter(strLicenseTo, strActivationCode)

            MsDoc = PDFWord.Documents.Open(GetWorkingDirectory.ToString() & "Source_docs\\tenpages.doc")

            'Make sure to set Background printing to OFF
            MsDoc.PrintOut(Background:=False)

            CType(MsDoc, Microsoft.Office.Interop.Word._Document).Close()

            'Reset the active printe back
            PDFWord.ActivePrinter = currentPrinter

            ListBox1.Items.Add("PrintMsWord_resulting.pdf ..... created")

        Catch Exc As Exception
            'Catch and display errors
            MsgBox("Error Printing")
        End Try

        'Clean up
        CType(PDFWord, Microsoft.Office.Interop.Word._Application).Quit()
        MsDoc = Nothing
        PDFWord = Nothing

        'PDF.DriverEnd()
        PDF.FileNameOptions = 0


    End Sub
End Class
